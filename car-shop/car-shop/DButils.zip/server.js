

var DButils = require('./DButils');
var Connection = require('tedious').Connection;
var Request = require('tedious').Request;
var express = require('express'); 
var bodyParser = require('body-parser');
var squel = require("squel");
var moment = require('moment'); 
var boolParser = require('express-query-boolean');
var passwordValidator = require('password-validator');

var schema = new passwordValidator();
schema
    .is().min(5)                                    // Minimum length 8 
    .is().max(10)                                  // Maximum length 100 
    .has().digits()                                 // Must have digits 
    .has().letters();                          // Should not have spaces 
//var validatorPass = new ValidatePassword(options);

//var validate = require("validate.js");
var validator = require('validator');
var expressValidator = require('express-validator');

var app = express();
//var Connection = require('tedious').Connection;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
var cors = require('cors'); 
app.use(cors()); 

var port = 5000;
app.listen(port, function () {
    console.log('listening to port: ' + port);
});


var config = {
    userName: 'ec', 
    password: 'Admin1234', 
    server: 'ec-server.database.windows.net',
    options: {
        encrypt: true,
        rowCollectionOnDone: true,
        database: 'EC_DB'
    }
}
var connection = new Connection(config);
var connection2 = new Connection(config);
var connection3 = new Connection(config);
var connection4 = new Connection(config);

console.log("connected"); 
  
connection.on('connect', function (err) {
    if (err) {
        console.log(err)
    }
    else {
        //Get all cars ordered By Category
        app.get('/GetListCarsOrderedByCategory', function (req, res) {         
            var query = (
                squel.select()
                    .from("Cars")                    
                    .order("Category")
                    .toString()
            );
            DButils.Select(connection, query, function (result) {
                res.send(result);
            });
        });

         //Get the 5 newest cars 
        app.get('/GetNewCars', function (req, res) {
            var query = "SELECT TOP 5 CarSeriesID FROM Cars ORDER BY DateOfEnter DESC";
            DButils.Select(connection, query, function (result) {
                res.send(result);
            });
        });


         //Get the List of the current Inventory
        app.get('/GetInventory', function (req, res) {
            var query = "SELECT CarSeriesID,Manufacture,ModelName,Year,NumInStock FROM Cars ORDER BY NumInStock DESC";
            DButils.Select(connection, query, function (result) {
                res.send(result);
            });
        });

         //Get a car details
        app.get('/GetCarDetails/:id', function (req, res) {
            var id = req.params.id;
            var ckeckQuery = (
                squel.select()
                    .from("Cars")
                    .where("CarSeriesID = ?", id)
                    .toString()
            );
            //check if the car exist in the system
            DButils.Select(connection2, ckeckQuery, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "Failed": " this ID  is Not exist" }));
                }


                else {
                    //Get the car's details
                    var query = (
                        squel.select()
                            .from("Cars")
                            .where("CarSeriesID = ?", id)
                            .toString()
                    );
                    DButils.Select(connection, query, function (result) {
                        res.send(result);
                    });
                }
            });
        });

        //Add new category to the system
        app.post('/addCategory', function (req, res) {
            var cat = req.body.Category;
            DButils.Insert(connection, "INSERT INTO Categories (Category) VALUES(@category)", cat, function (result) {
                var sent = false;
                for (var obj in result) {
                    if (!sent) {
                        if (obj === "Success") {
                            sent = true;
                            res.send(JSON.stringify({ "Sucess": "" + cat + " Added" }));
                        }
                        else {
                            sent = true;
                            res.send(result);

                        }
                    }
                }
               
            });
        });

        //Updete the inventory with new units of certain car
        app.put('/UpdateInventory', function (req, res) {
            var id = req.body.CarSeriesID.toString();
            var units = parseInt(req.body.NewUnitsToAdd);

            var ckeckQuery = (
                squel.select()
                    .from("Cars")
                    .where("CarSeriesID = ?", id)
                    .toString()
            );
            //Check if the car is exist
            DButils.Select(connection2, ckeckQuery, function (result){
                if (result.length == 0) {
                    res.send(JSON.stringify({ "Failed": " this ID  is Not exist" }));
                }

                else {
                    var query = (
                        squel.update()
                            .table("Cars")
                            .set("NumInStock = NumInStock + " + units)
                            .where("CarSeriesID = ?", id)
                            .toString()
                    );
                    //add the new units to the inventory
                    DButils.Update(connection, query, function (result) {

                        var sent = false;
                        for (var obj in result) {
                            if (!sent) {
                                if (obj === "Success") {
                                    sent = true;
                                    res.send(JSON.stringify({ "Sucess": "" + id + "Stock was Updated" }));
                                }
                                else {
                                    sent = true;
                                    res.send(result);
                                }
                            }
                        }                     
                    });
                }
                });
                       
        });

        //Check if wanted units of a car exist in the inventory
        app.post('/CheckIsInStock', function (req, res) {
            var id = req.body.CarSeriesID.toString();
            var units = parseInt(req.body.Units);

            var ckeckQuery = (
                squel.select()
                    .from("Cars")
                    .where("CarSeriesID = ?", id)
                    .where("NumInStock >= ?",units)
                    .toString()
            );
            DButils.Select(connection2, ckeckQuery, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "False": " NotInStock" }));
                }

                else{

                    res.send(JSON.stringify({ "True": " InStock" }));
                }
            });

        });

        //get user's prev orders'
        app.post('/getPrevOrders', function (req, res) {
            var username = req.body.username;     
            var query = (
                squel.select()
                    .field("OrderID")
                    .field("Date")
                    .from("Orders")
                    .where("username = ?", username) 
                    .order("Date")
                    .toString()
            );
            DButils.Select(connection, query, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "False": " Not found any order" }));
                }
                else
                {
                    res.send(result);
                }
            });

        });

        //get order's details
        app.post('/getOrderDetails', function (req, res) {
            var orderId = parseInt(req.body.OrderID);
            var query = (
                squel.select()
                    .field("CarSeriesID")
                    .field("Quantity")
                    .from("CarsInOrder")
                    .where("OrderID = ?", orderId)
                    .toString()
            );
            DButils.Select(connection, query, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "False": " OrderId not exist" }));
                }
                else {
                    res.send(result);
                }
            });

        });


        //Update user to be admin
        app.put('/AddAdmin', function (req, res) {
            var _username = req.body.username;   
            var ckeckQuery = (
                squel.select()
                    .from("Users")
                    .where("username = ?", _username)
                    .toString()
            );
            //check if the user exist
            DButils.Select(connection2, ckeckQuery, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "Failed": " the username  is Not exist" }));
                }
                else {
          
                  var query = (
                        squel.update()
                            .table("Users")
                            .set("IsAdmin = 1")
                            .where("username = ?",_username)
                            .toString()
                    );
                    //return the result                  
                    DButils.Update(connection, query, function (result) {                    
                        var sent = false;
                        for (var obj in result) {
                            if (!sent) {
                                if (obj === "Success") {
                                    sent = true;
                                    res.send(JSON.stringify({ "Sucess": "" + _username + "is admin now" }));
                                }
                                else {
                                    sent = true;
                                    res.send(result);

                                }
                            }
                         }


                    });
                }
            });
        });

        //add new car to the system
        app.post('/addCar', function (req, res) {

         
            var date = moment().format('YYYY-MM-DD hh:mm:ss');
            var id = req.body.CarSeriesID;
            var cat = req.body.cat;
            var man = req.body.Manufacture;
            var model = req.body.ModelName;
            var year = parseInt(req.body.Year, 10);
            var color = req.body.Color;
            var price = parseInt(req.body.Price, 10);
            var num = parseInt(req.body.NumInStock, 10);
            //check if the wanted id is already in the system
            var ckeckQuery = (
                squel.select()
                    .from("Cars")
                    .where("CarSeriesID = ?", id)
                    .toString()
            );
            DButils.Select(connection2, ckeckQuery, function (result) {
                if (result.length > 0) {
                    res.send(JSON.stringify({ "Failed": " this ID  already exists, select another Id " }));
                }

                else {
                  
                    var query = (
                        squel.insert()
                            .into("Cars")
                            .set("CarSeriesID", id)
                            .set("Category", cat)
                            .set("Manufacture", man)
                            .set("ModelName", model)
                            .set("Year", year)
                            .set("Color", color)
                            .set("PriceNIS", price)
                            .set("NumInStock", num)
                            .set("DateOfEnter", date)
                            .toString()
                    );
                    DButils.Insert(connection, query, function (result) {
                        //return the result
                        var sent = false;
                        for (var obj in result) {
                            if (!sent) {
                                if (obj === "Success") {
                                    sent = true;
                                    res.send(JSON.stringify({ "Sucess": "" + id + " Added" }));
                                }
                                else {
                                    sent = true;
                                    res.send(result);
                                   
                                }
                            }
                        }

                    });
                }
             });
        });
            
        //Delete a car from the system
        app.delete('/deleteCar', function (req, res) {
            var carID = req.body.CarSeriesID;

            var ckeckQuery = (
                squel.select()
                    .from("Cars")
                    .where("CarSeriesID = ?", carID)
                    .toString()
            );
            DButils.Select(connection2, ckeckQuery, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "Failed": " this ID  is Not exist" }));
                }
                else {

                    var query = (
                        squel.delete()
                            .from("Cars")
                            .where("CarSeriesID = ?", carID)
                            .toString()
                    );                  
                    DButils.Delete(connection, query, function (result) {
                      
                        res.send(result);
                    });

                    }
                   });
                
               
        });


        //Buy A whole shopping cart
        app.post('/BuyCart', function (req, res) {

            var nextOrderID = 1;
            var cars = req.body.Items;
            var username = req.body.username;
            var totalPrice = req.body.totalPrice;
            var currency = req.body.currency;
            var date = moment().format('YYYY-MM-DD hh:mm:ss');
            var deliveryDate = req.body.deliveryDate;


            var rows = [];
          
          
            var keys = Object.keys(cars[0]);
            for (var i = 0; i < keys.length; i++) {
                console.log(keys[i]);
                console.log(cars[0][keys[i]]);
            }
            //check if the username exist 
            var ckeckQueryUserName = (
                squel.select()
                    .from("Users")
                    .where("username = ?", username)
                    .toString()
            );
            DButils.Select(connection2, ckeckQueryUserName, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "Failed": " The user " +username+" not exist" }));
                }
                //find next available orderid
                else {
                    var nextOrderIDQuery = (
                        squel.select()                      
                            .from("Orders")
                             .field("MAX(OrderID)","max")
                        .toString()
                    );
                    DButils.Select(connection3, nextOrderIDQuery, function (result3) {
                        if (!(result3[0].max === null))
                        nextOrderID = parseInt(result3[0].max) + 1;
                        console.log("nextID");
                        console.log(nextOrderID);
                        //create the order
                    var queryAddOrder = (
                        squel.insert()
                            .into("Orders")
                            .set("username", username)
                            .set("OrderID", nextOrderID)
                            .set("Date", date)
                            .set("Price", totalPrice)
                            .set("Currency", currency)
                            .set("DeliveryDate", deliveryDate)
                            .toString()
                    );
                    DButils.Insert(connection4, queryAddOrder, function (result4) {
                        console.log(result4);

                    //set an array to add to the db
                    for (var i = 0; i < keys.length; i++) {

                        var item = {};
                        item["OrderID"] = nextOrderID;
                        item["CarSeriesID"] = keys[i];
                        item["Quantity"] = cars[0][keys[i]];                     
                        rows.push(item);
                    }

                    var queryAddCarsToOrder = (
                        squel.insert()
                            .into("CarsInOrder")
                            .setFieldsRows(rows)
                            .toString()
                    );
                        //add the cars to the order
                    DButils.Insert(connection, queryAddCarsToOrder, function (result) {
                       // res.send(result);

                        var sent = false;
                        for (var obj in result) {
                            if (!sent) {
                                if (obj === "Success") {
                                    sent = true;
                                    res.send(JSON.stringify({ "Sucess": "Order Number " + nextOrderID + " Created and aproved" }));
                                }
                                else {
                                    sent = true;
                                    res.send(result);

                                }
                            }
                        }
                    });
                    });

                });
                }
            });
        });

        //Buy one car
        app.post('/BuyCar', function (req, res) {

            var nextOrderID = 1;
            var carSeriesID = req.body.carSeriesID;
            var username = req.body.username;
            var totalPrice = req.body.totalPrice;
            var currency = req.body.currency;
            var date = moment().format('YYYY-MM-DD hh:mm:ss');
            var deliveryDate = req.body.deliveryDate;

            var rows = []
            //check if the user exist
            var ckeckQueryUserName = (
                squel.select()
                    .from("Users")
                    .where("username = ?", username)
                    .toString()
            );
            DButils.Select(connection2, ckeckQueryUserName, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "Failed": " The user " + username + " not exist" }));
                }
                //find free order number
                else {
                    var nextOrderIDQuery = (
                        squel.select()
                            .from("Orders")
                            .field("MAX(OrderID)", "max")
                            .toString()
                    );
                    DButils.Select(connection3, nextOrderIDQuery, function (result3) {
                        if (!(result3[0].max === null))
                            nextOrderID = parseInt(result3[0].max) + 1;
                        console.log("nextID");
                        console.log(nextOrderID);

                        var queryAddOrder = (
                            squel.insert()
                                .into("Orders")
                                .set("username", username)
                                .set("OrderID", nextOrderID)
                                .set("Date", date)
                                .set("Price", totalPrice)
                                .set("Currency", currency)
                                .set("DeliveryDate", deliveryDate)
                                .toString()
                        );
                        DButils.Insert(connection4, queryAddOrder, function (result4) {
                            console.log(result4);
                               //create the order
                            var queryAddCarToOrder = (
                                squel.insert()
                                    .into("CarsInOrder")
                                    .set("OrderID", nextOrderID)
                                    .set("CarSeriesID", carSeriesID)
                                    .set("Quantity", 1)
                                    .toString()
                            );
                            DButils.Insert(connection, queryAddCarToOrder, function (result) {
                                //add the car to the order
                                var sent = false;
                                for (var obj in result) {
                                    if (!sent) {
                                        if (obj === "Success") {
                                            sent = true;
                                            res.send(JSON.stringify({ "Sucess": "Order Number " + nextOrderID + " Created and aproved" }));
                                        }
                                        else {
                                            sent = true;
                                            res.send(result);

                                        }
                                    }
                                }                            
                            });
                        });

                    });
                }
            });
        });


        //Get list of the popular cars
        app.get('/GetPopularCars', function (req, res) {
            var query = ' SELECT TOP(2) CarSeriesID,SUM (Quantity) as Sold FROM CarsInOrder GROUP BY CarSeriesID ORDER BY Sold DESC';
            DButils.Select(connection, query, function (result) {
                res.send(result);
            });
        });


        //Get All orders
        app.get('/GetAllOrders', function (req, res) {
            var query = ' SELECT * FROM ORDERS';
            DButils.Select(connection, query, function (result) {
                res.send(result);
            });
        });

        //get list of all the categories
        app.get('/GetAllCategories', function (req, res) {
            var query = ' SELECT * FROM Categories';
            DButils.Select(connection, query, function (result) {
                res.send(result);
            });
        });

        //Delete client
        app.delete('/deleteClient', function (req, res) {
            var _username = req.body.username;

            var ckeckQuery = (
                squel.select()
                    .from("Users")
                    .where("username = ?", _username)
                    .toString()
            );
            DButils.Select(connection2, ckeckQuery, function (result) {
                if (result.length == 0) {
                    res.send(JSON.stringify({ "Failed": " the username  is Not exist" }));
                }
                else {

                    var query = (
                        squel.delete()
                            .from("Users")
                            .where("username = ?", _username)
                            .toString()
                    );
                    DButils.Delete(connection, query, function (result) {
                        res.send(result);
                    });

                }
            });


        });

        //Add new user to the system
        app.post('/Register', function (req, res) {
            console.log("start");
            var _username = req.body.username;
            var _password = req.body.password;
            var _FirstName = req.body.FirstName;
            var _LastName = req.body.LastName;
            var _Email = req.body.Email;
            var _Address = req.body.Address;
            var _Country = req.body.Country;
            var _Q1 = req.body.Q1;
            var _Ans1 = req.body.Ans1;
            var _Q2 = req.body.Q2;
            var _Ans2 = req.body.Ans2;
            var _Telephone = req.body.Telephone;
            var EmailVal = validator.isEmail(_Email);
            var options = { min: 3, max: 8 };
            var args = validator.isByteLength(_username, options);
            var optionsPas = { min: 5, max: 10 };
            var argsPass = validator.isByteLength(_password, optionsPas);
            var isLetters = validator.isAlpha(_username);
            var isLettersOrNum = validator.isAlphanumeric(_password);
            var passValied = schema.validate(_password)
            if (!(args)) {
                console.log("not Valid User Name");
                res.send(JSON.stringify({ "Failed": "The length of the user Name should be between 3-8 chars" }));
            }

            else if (!(argsPass)) {
                console.log("not Valid Password");
                res.send(JSON.stringify({ "Failed": "The length of the Password should be between 5-10 chars" }));
            }
            else if (!(isLetters)) {
                console.log("not Valid User Name");
                res.send(JSON.stringify({
                    "Failed": "The User Name should Contains only letters"
                }));
            }
            else if (!(isLettersOrNum) || !(passValied)) {
                console.log("not Valid Password");
                res.send(JSON.stringify({ "Failed": " The password should contain only a combination of letters and numbers" }));
            }
            else if (!(EmailVal)) {
                console.log("not Email");
                res.send(JSON.stringify({ "Failed": "The Email not Valid" }));

            }

            /*
        else {
            console.log("Valid ");
            res.send(JSON.stringify({ "success": "success" }));
        }
        */
            var query = (
                squel.select()
                    .from("Users")
                    .where("username = ?", _username)
                    .toString()
            );
            DButils.Select(connection, query, function (result) {
                if (result.length > 0) {
                    console.log("not Valid User Name");
                    res.send(JSON.stringify({ "Failed": " Username already exists, select another user name " }));
                }
                else {

                    var query2 = (
                        squel.insert()
                            .into("Users")
                            .set("username", _username)
                            .set("password", _password)
                            .set("FirstName", _FirstName)
                            .set("LastName", _LastName)
                            .set("Email", _Email)
                            .set("Address", _Address)
                            .set("Country", _Country)
                            .set("Q1", _Q1)
                            .set("Ans1", _Ans1)
                            .set("Q2", _Q2)
                            .set("Ans2", _Ans2)
                            .set("Telephone", _Telephone)
                            .set("IsAdmin", 0) //set is admin to false
                            .toString()
                    );
                    DButils.Insert(connection2, query2, function (result) {
                        // res.send("zfdhlkjxfghjdlfkjhg");
                        //res.send(result);

                        if (result) {
                            console.log("Valid ");
                            res.send(JSON.stringify({ "success": "New user created" }));

                        }

                        //console.log(res);
                        // })

                    });
                }
                /*
                else {

                    console.log("Valid ");
                    res.send(JSON.stringify({ "success": "success" }));

                }
                */
            });


            // })

        });

       


 



            }
});

    


   
    
    
     
    /**
    
    
    var query = "select * from Categories"; 
    var Request = require('tedious').Request;
    var TYPES = require('tedious').TYPES;
    var req = new Request(query, function (err, rowCount){}); 
    Connection.execSql(req);
    console.log("selected");
    
    app.get('/select1', function (req, res){
        Select(Connection, query, function (result){
    
            res.send(result);
        }
    );
    
    
    
    
    
    Select = function (connection, query, callback) {
        var req = new Request(query,  function(err, rowCount){
            if (err){
    
                console.log(err);
            }
        });
    
        /**
        
        var res = []; 
        var properties = [];
        req.on()
        connection.execSql()
         *
         */

